package com.sensetime.interactive;

public class Constants {

    public static final String FACE_LICENSE_FILE_NAME =
            //"SSID_LIVENESS_INTERACTIVE.lic";
            "License2.lic";
    public static final String MODEL_ALIGN_FILE_NAME =
            "KM_Align_occlusion_106_1.19.6.model";
    public static final String MODEL_AUGUST_FACE_FILE_NAME =
            "KM_August_Face_Gray_PPL_2.6.3_half_compression_v2_origin.model";
    public static final String MODEL_EYESTATE_FILE_NAME =
            "KM_eyestate_ppl_3.6.1_half_compression_v2_origin.model";
    public static final String MODEL_HEADPOSE_FILE_NAME =
            "KM_Headpose_106_ppl_2.3.0_half_compression_v2_origin.model";
    public static final String MODEL_HUNTER_FILE_NAME =
            "KM_Hunter_SmallFace_Gray_ppl_9.6.1_half_compression_v1_weak.model";
    public static final String MODEL_PAGEANT_FILE_NAME =
            "KM_Pageant_88id_Fcfp32_ppl_1.0.7_half_compression_v2_origin.model";
    public static final String MODEL_RGB_GENERAL_FILE_NAME =
            "KM_RGB_Liveness_General_Face_FP32_12.1.44_half_compression_v2_origin.model";
}
