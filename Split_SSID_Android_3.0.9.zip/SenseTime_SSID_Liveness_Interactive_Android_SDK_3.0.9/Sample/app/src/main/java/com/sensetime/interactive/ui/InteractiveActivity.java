package com.sensetime.interactive.ui;

import static com.sensetime.interactive.ui.InteractiveResultActivity.mFaceRects;
import static com.sensetime.interactive.ui.InteractiveResultActivity.mSTImages;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.STException.ERR_ENV_EXCEPTION;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_ANGLE_FAIL;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_EYES_CLOSED;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_HEADPOSE_ANGLE_FAIL;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_LIGHT_OVER_EXPOSURE;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_LIGHT_TOO_DIM;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_MULTIPLE_FACE;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_OCCLUSION_BROW;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_OCCLUSION_EYE;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_OCCLUSION_MOUTH;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_OCCLUSION_NOSE;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_OUT_OF_ROI;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_TOO_BLUR;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_TOO_LARGE;
import static com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus.ST_PHASE_STATUS_TOO_SMALL;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import com.sensetime.interactive.Constants;
import com.sensetime.interactive.R;
import com.sensetime.interactive.utils.FileUtil;
import com.sensetime.ssidmobile.sdk.liveness.interactive.OnInteractiveCalibrationListener;
import com.sensetime.ssidmobile.sdk.liveness.interactive.OnInteractiveColorfulListener;
import com.sensetime.ssidmobile.sdk.liveness.interactive.OnInteractiveLivenessListener;
import com.sensetime.ssidmobile.sdk.liveness.interactive.OnLogsCallback;
import com.sensetime.ssidmobile.sdk.liveness.interactive.STException;
import com.sensetime.ssidmobile.sdk.liveness.interactive.STInteractiveLivenessDetector;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.CalibrationStatus;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.FaceStatus;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.InteractiveResult;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.Location;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.Motion;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.ResultCode;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.STPixelFormat;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.config.InteractiveConfig;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.config.ModelsConfig;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.config.ThresholdConfig;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.hardware.Camera;
import android.os.Bundle;
import android.support.annotation.Nullable;

import android.widget.Toast;

/**
 * @date: Create in 10:17 AM 2020/4/27
 * @author: chenliang
 * @description please add a description here
 */
public class InteractiveActivity extends AbstractCameraActivity
        implements OnInteractiveLivenessListener,
                OnLogsCallback {

    public static void start(Context context) {
        context.startActivity(new Intent(context, InteractiveActivity.class));
    }

    static final int[] DEFAULT_MOTIONS = new int[] {
            Motion.BLINK,
            Motion.MOUTH,
            Motion.NOD,
            Motion.YAW
    };

    private CountDownLatch countDownLatch;
    private STInteractiveLivenessDetector mDetector;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
    }

    private void init() {
        changeHint(R.string.common_loading);
        final FutureTask<String>[] assetsCopyFutureTasks = new FutureTask[]{
                copyFutureTask(Constants.FACE_LICENSE_FILE_NAME),
                copyFutureTask(Constants.MODEL_ALIGN_FILE_NAME),
                copyFutureTask(Constants.MODEL_AUGUST_FACE_FILE_NAME),
                copyFutureTask(Constants.MODEL_EYESTATE_FILE_NAME),
                copyFutureTask(Constants.MODEL_HEADPOSE_FILE_NAME),
                copyFutureTask(Constants.MODEL_HUNTER_FILE_NAME),
                copyFutureTask(Constants.MODEL_PAGEANT_FILE_NAME),
                copyFutureTask(Constants.MODEL_RGB_GENERAL_FILE_NAME),
        };

        countDownLatch = new CountDownLatch(assetsCopyFutureTasks.length);
        ExecutorService cachedThreadPool = Executors.newCachedThreadPool();
        for (FutureTask futureTask : assetsCopyFutureTasks) {
            cachedThreadPool.submit(futureTask);
        }
        // 等待融云的回调触发
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
        }
        try {
            mDetector = new STInteractiveLivenessDetector();
            mDetector.initWithConfig(InteractiveActivity.this,
                            new InteractiveConfig.Builder()
                                    .withLicensePath(assetsCopyFutureTasks[0].get())
                                    .withModelsConfig(new ModelsConfig.Builder()
                                            .withAlignModelPath(assetsCopyFutureTasks[1].get())
                                            .withAugustModelPath(assetsCopyFutureTasks[2].get())
                                            .withEyeStateModelPath(assetsCopyFutureTasks[3].get())
                                            .withHeadPoseModelPath(assetsCopyFutureTasks[4].get())
                                            .withHunterModelPath(assetsCopyFutureTasks[5].get())
                                            .withPageantModelPath(assetsCopyFutureTasks[6].get())
                                            .withLivenessModelPath(assetsCopyFutureTasks[7].get())
                                            .build())
                                    .withThresholdConfig(new ThresholdConfig.Builder().build())
                                    .build(),
                            InteractiveActivity.this);
            mFaceOverlayView.post(new Runnable() {
                @Override
                public void run() {
                    mDetector.setOrientation(mFaceOrientation);
                    Rect rect = mCameraPreview.convertViewRectToCameraPreview(
                            mFaceOverlayView.getMaskBounds());
                    STInteractiveLivenessDetector.enableLog(true, InteractiveActivity.this);
                    //处理
                    mDetector.setTargetRect(rect);
                    mDetector.setDetectMotionTypes(DEFAULT_MOTIONS);
                    mDetector.start();
                    changeHint(R.string.common_ready);
                }
            });

        } catch (STException e) {
            e.printStackTrace();
            changeHint(R.string.common_load_error);
            Toast.makeText(InteractiveActivity.this, e.getLocalizedMessage(),
                    Toast.LENGTH_LONG).show();
        } catch (InterruptedException e) {
            e.printStackTrace();
            changeHint(R.string.common_load_error);
            Toast.makeText(InteractiveActivity.this, e.getLocalizedMessage(),
                    Toast.LENGTH_LONG).show();
        } catch (ExecutionException e) {
            e.printStackTrace();
            changeHint(R.string.common_load_error);
            Toast.makeText(InteractiveActivity.this, e.getLocalizedMessage(),
                    Toast.LENGTH_LONG).show();
        }

        cachedThreadPool.shutdown();

    }

    private FutureTask<String> copyFutureTask(final String name) {
        return new FutureTask<>(new Callable<String>() {
            @Override
            public String call() {
                String destAbsolutePath = FileUtil.copyAssetsToFile(
                        getApplicationContext(),
                        name,
                        getCacheDir().getAbsolutePath() + "/assets/"
                );
                countDownLatch.countDown();
                return destAbsolutePath;
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        mDetector.destroy();
        mFaceOverlayView.release();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onFaceLocation(Location location) {
        //人脸实时位置
    }
    private long mFaceCount;

    @Override
    public void onFaceCount(final int faceCount) {
        mFaceCount = faceCount ;
    }

    @Override
    public void onStatusUpdate(@FaceStatus int faceState) {
        if (faceState == ST_PHASE_STATUS_OCCLUSION_BROW) {
            changeHint(R.string.error_status_occlusion_brow);
        } else if (faceState == ST_PHASE_STATUS_OCCLUSION_EYE) {
            changeHint(R.string.error_status_occlusion_eye);
        } else if (faceState == ST_PHASE_STATUS_EYES_CLOSED) {
            changeHint(R.string.error_status_eye_closed);
        } else if (faceState == ST_PHASE_STATUS_OCCLUSION_NOSE) {
            changeHint(R.string.error_status_occlusion_nose);
        } else if (faceState == ST_PHASE_STATUS_OCCLUSION_MOUTH) {
            changeHint(R.string.error_status_occlusion_mouth);
        } else if (faceState == ST_PHASE_STATUS_TOO_LARGE) {
            changeHint(R.string.error_status_too_close);
        } else if (faceState == ST_PHASE_STATUS_TOO_SMALL) {
            changeHint(R.string.error_status_too_far);
        } else if (faceState == ST_PHASE_STATUS_OUT_OF_ROI) {
            restartDetectorByLimit();
        } else if (faceState == ST_PHASE_STATUS_HEADPOSE_ANGLE_FAIL) {
            changeHint(R.string.error_face_angle_error);
        } else if (faceState == ST_PHASE_STATUS_TOO_BLUR) {
            changeHint(R.string.error_pageant_blur);
        } else if (faceState == ST_PHASE_STATUS_LIGHT_TOO_DIM || faceState == ST_PHASE_STATUS_LIGHT_OVER_EXPOSURE) {
            changeHint(R.string.error_light_to_dim);
        } else if (faceState == ST_PHASE_STATUS_ANGLE_FAIL) {
            changeHint(R.string.common_ready);
        } else if (faceState == ST_PHASE_STATUS_MULTIPLE_FACE) {
            changeHint(R.string.error_face_count_cheek);
        } else {
            isDetecting = true;
            try {
                changeHint(R.string.txt_hint_null);
            } catch (Exception e) {
                changeHint(R.string.common_ready);
            }
        }

    }

    @Override
    public void onSuccess(final InteractiveResult[] interactiveResults) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final InteractiveResultActivity.Result interactiveResult =
                        new InteractiveResultActivity.Result();
                interactiveResult.resultCode = ResultCode.OK;
                if(interactiveResults != null && interactiveResults.length > 0){
                    for (InteractiveResult interactiveResult1 : interactiveResults) {
                        if (interactiveResult1 == null) {
                            continue;
                        }
                        mSTImages.add(interactiveResult1.resultJPEGImage);
                        Location location = interactiveResult1.location;
                        mFaceRects.add(new Rect(location.left, location.top,
                                location.right,location.bottom));
                    }
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                        InteractiveResultActivity
                                .start(InteractiveActivity.this, interactiveResult);
                    }
                });
            }
        }).start();
    }

    @Override
    public void onFailure(@ResultCode final int resultCode, final InteractiveResult[] interactiveResults) {
        if(resultCode == ResultCode.FACE_LOST){
            if(isDetecting){
                restartDetectorByLimit();
            }else {
                changeHint(R.string.error_status_out_bound);
                mDetector.reStart();
            }
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                final InteractiveResultActivity.Result interactiveResult =
                        new InteractiveResultActivity.Result();
                interactiveResult.resultCode = resultCode;
                if(interactiveResults != null && interactiveResults.length > 0){
                    for (InteractiveResult interactiveResult1 : interactiveResults) {
                        if (interactiveResult1 == null) {
                            continue;
                        }
                        mSTImages.add(interactiveResult1.resultJPEGImage);
                        Location location = interactiveResult1.location;
                        mFaceRects.add(new Rect(location.left, location.top,
                                location.right,location.bottom));
                    }
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                        InteractiveResultActivity
                                .start(InteractiveActivity.this, interactiveResult);
                    }
                });
            }
        }).start();
    }

    @Override
    public void onMotionSet(int index, int motion) {
        changeMotionHint(getDescription(motion));
    }

    @Override
    public void onPreviewFrame(byte[] bytes, Camera camera) {
        try{
            if (mDetector != null) {
                mDetector.input(bytes, STPixelFormat.NV21, WIDTH, HEIGHT);
            }
        }catch (STException exception){
            if(exception.code == ERR_ENV_EXCEPTION){
                changeHint(R.string.common_error_system_risk);
            }
        }
    }

    private int getDescription(@Motion int motion) {
        int nameResID;
        if (Motion.YAW == motion) {
            nameResID = R.string.common_yaw_description;
        } else if (Motion.BLINK == motion) {
            nameResID = R.string.common_blink_description;
        } else if (Motion.MOUTH == motion){
            nameResID =  R.string.common_mouth_description;
        } else if (Motion.NOD == motion) {
            nameResID = R.string.common_nod_description;
        } else {
            nameResID = R.string.common_unknow_tag;
        }
        return nameResID;
    }

    private int restartTimes = 0;
    private int restartTimesLimit = 3;
    private boolean isDetecting = false;
    private void restartDetectorByLimit(){
        if(!isDetecting){
            return;
        }
        if(restartTimes < restartTimesLimit){
            isDetecting = false;
            restartTimes++;
            changeHint(R.string.error_status_out_bound);
            mDetector.reStart();

        }else if(restartTimes >= restartTimesLimit){
            finish();
            final InteractiveResultActivity.Result interactiveResult =
                    new InteractiveResultActivity.Result();
            interactiveResult.resultCode = ResultCode.FACE_LOST;
            InteractiveResultActivity
                    .start(InteractiveActivity.this, interactiveResult);
        }
    }

    @Override
    public void onLogs(int i, String s) {
    }
}
