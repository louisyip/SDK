package com.sensetime.interactive.ui;

import java.util.Locale;

import com.sensetime.interactive.camera.SenseCamera;
import com.sensetime.interactive.camera.SenseCameraPreview;
import com.sensetime.interactive.widget.FaceOverlayView;
import com.sensetime.interactive.R;
import com.sensetime.interactive.utils.FileUtil;
import com.sensetime.ssidmobile.sdk.liveness.interactive.OnInteractiveLivenessListener;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.STImageOrientation;

import android.content.Context;
import android.hardware.Camera;
import android.hardware.Camera.PreviewCallback;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.v4.app.FragmentActivity;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @Author: zhuyulinag
 * @CreateDate: 2020/4/30 5:42 PM
 * @Description: 相机预览
 */
public abstract class AbstractCameraActivity extends FragmentActivity
        implements OnInteractiveLivenessListener, PreviewCallback {

    protected static final int WIDTH = SenseCamera.DEFAULT_PREVIEW_SIZE.getWidth();

    protected static final int HEIGHT = SenseCamera.DEFAULT_PREVIEW_SIZE.getHeight();

    protected SenseCameraPreview mCameraPreview;
    protected TextView mTxtHint;
    protected TextView mMotionTextView;
    protected FaceOverlayView mFaceOverlayView;
    private int mCameraID = SenseCamera.CAMERA_FACING_FRONT;

    private SenseCamera mSenseCamera;
    protected int mFaceOrientation = STImageOrientation.RIGHT;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camrea);
        mCameraPreview = findViewById(R.id.cameraPreview);
        mMotionTextView = findViewById(R.id.layout_motions_hint);
        mTxtHint = findViewById(R.id.hint);

        mFaceOverlayView = findViewById(R.id.faceOverlayView);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        initCamera(SenseCamera.CAMERA_FACING_FRONT);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSenseCamera.release();
        mCameraPreview.release();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void initCamera(int cameraID) {
        mFaceOrientation = getCameraOrigin(mCameraID);
        mCameraID = cameraID;
        if (mSenseCamera != null) {
            this.mSenseCamera.release();
        }
        this.mSenseCamera = new SenseCamera.Builder(this)
                .setCameraId(mCameraID)
                .setFacing(mCameraID)
                .setRequestedPreviewSize(WIDTH, HEIGHT)
                .build();
        try {
            this.mCameraPreview.start(this.mSenseCamera);
            this.mSenseCamera.setOnPreviewFrameCallback(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void changeHint(@StringRes final int res) {
        mTxtHint.post(
                new Runnable() {
                    @Override
                    public void run() {
                        mTxtHint.setText(res);
                    }
                }
        );
    }

    public void changeMotionHint(@StringRes final int res) {
        mMotionTextView.post(
                new Runnable() {
                    @Override
                    public void run() {
                        mMotionTextView.setText(res);
                    }
                }
        );
    }

    public void toast(@StringRes int resId){
        Toast.makeText(this,resId,Toast.LENGTH_SHORT).show();
    }

    public @STImageOrientation int getCameraOrigin(int cameraId){
        final WindowManager windowManager = (WindowManager)
                this.getSystemService(Context.WINDOW_SERVICE);
        int degrees = 0;
        int rotation = windowManager != null ?
                windowManager.getDefaultDisplay().getRotation() : Surface.ROTATION_0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
            default:
                break;
        }
        final Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(cameraId, cameraInfo);
        int angle;
        int displayAngle;
        if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            angle = (cameraInfo.orientation + degrees) % 360;
            displayAngle = (360 - angle) % 360; // compensate for it being mirrored
        } else {  // back-facing
            angle = (cameraInfo.orientation - degrees + 360) % 360;
            displayAngle = angle;
        }

        switch (angle){
            case 0:
                return STImageOrientation.UP;
            case 90:
                return STImageOrientation.LEFT;
            case 180:
                return STImageOrientation.DOWN;
            case 270:
                return STImageOrientation.RIGHT;
        }
        return STImageOrientation.RIGHT;
    }
}