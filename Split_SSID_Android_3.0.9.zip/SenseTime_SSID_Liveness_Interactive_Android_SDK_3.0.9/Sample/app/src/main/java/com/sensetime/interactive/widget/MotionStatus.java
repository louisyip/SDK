package com.sensetime.interactive.widget;

import com.sensetime.interactive.R;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.Motion;

/**
 * @date: Create in 10:13 AM 2020/4/29
 * @author: chenliang
 * @description 动作状态
 */
public class MotionStatus {

    public @Motion
    int motion;

    public int nameResID;

    public int descriptionResID;

    public MotionPhase motionPhase;

    public MotionStatus(@Motion int motion) {
        this.motion = motion;
        this.nameResID = getNameResID(motion);
        this.motionPhase = MotionPhase.UNDO;
        this.descriptionResID = getDescription(motion);
    }

    public enum MotionPhase {
        UNDO,
        CURRENT,
        COMPLETED
    }

    private int getNameResID(@Motion int motion) {
        int nameResID;
        if (Motion.YAW == motion) {
            nameResID = R.string.common_yaw_tag;
        } else if (Motion.BLINK == motion) {
            nameResID = R.string.common_blink_tag;
        } else if (Motion.MOUTH == motion) {
            nameResID = R.string.common_mouth_tag;
        } else if (Motion.NOD == motion) {
            nameResID = R.string.common_nod_tag;
        } else {
            nameResID = R.string.common_unknow_tag;
        }
        return nameResID;
    }

    private int getDescription(@Motion int motion) {
        int nameResID;
        if (Motion.YAW == motion) {
            nameResID = R.string.common_yaw_description;
        } else if (Motion.BLINK == motion) {
            nameResID = R.string.common_blink_description;
        } else if (Motion.MOUTH == motion) {
            nameResID = R.string.common_mouth_description;
        } else if (Motion.NOD == motion) {
            nameResID = R.string.common_nod_description;
        } else {
            nameResID = R.string.common_unknow_tag;
        }
        return nameResID;
    }
}
