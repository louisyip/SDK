package com.sensetime.interactive.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.os.Build;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public abstract class AbstractOverlayView extends View {
    private Path mPath = new Path();
    private Paint mPaint;
    private Paint mBackgroundPaint;

    private Timer mTimer;
    private ArrayList<Integer> mBackgroundColorList;
    private boolean mBrilliantRun;

    private int mBackgroundColor = Color.parseColor("#66020202");

    public AbstractOverlayView(Context context) {
        super(context);
        this.init();
    }

    public AbstractOverlayView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.init();
    }

    public AbstractOverlayView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.init();
    }

    private void init() {
        mBackgroundColorList = getBackgroundColor();
        this.mPaint = new Paint();
        this.mPaint.setStyle(Paint.Style.STROKE);
        this.mPaint.setColor(Color.GRAY);
        this.mPaint.setStrokeWidth(2);
    }

    private Paint getBackgroundPaint() {
        if (this.mBackgroundPaint != null) {
            return mBackgroundPaint;
        }
        this.mBackgroundPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        this.mBackgroundPaint.clearShadowLayer();
        this.mBackgroundPaint.setStyle(Paint.Style.FILL);
        this.mBackgroundPaint.setColor(this.mBackgroundColor);
        return this.mBackgroundPaint;
    }

    protected abstract void buildPath(@NonNull final Path path, final int viewWidth, final int viewHeight);

    public abstract Rect getMaskBounds();

    /**
     * Set background color.
     *
     * @param color color.
     */
    public void setBackgroundColor(@ColorInt final int color) {
        this.mBackgroundColor = color;
        this.postInvalidate();
    }

    /**
     * Set mask path color.
     *
     * @param color color
     */
    public void setMaskPathColor(@ColorInt final int color) {
        this.mPaint.setColor(color);
        this.invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();
        this.mPath.reset();
        this.buildPath(this.mPath, this.getWidth(), this.getHeight());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            canvas.clipOutPath(this.mPath);
            canvas.drawColor(this.mBackgroundColor);
            canvas.restore();
            canvas.drawPath(this.mPath, this.mPaint);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            canvas.clipPath(this.mPath, Region.Op.DIFFERENCE);
            canvas.drawColor(this.mBackgroundColor);
            canvas.restore();
            canvas.drawPath(this.mPath, this.mPaint);
        } else {
            @SuppressLint("DrawAllocation")
            final Path path = new Path();
            @SuppressLint("DrawAllocation")
            final RectF board = new RectF(0, 0, this.getMeasuredWidth(), this.getMeasuredHeight());
            path.addRect(board, Path.Direction.CCW);
            path.addPath(this.mPath);
            canvas.drawPath(path, this.getBackgroundPaint());
            canvas.drawPath(this.mPath, this.mPaint);
            canvas.restore();
        }
    }

    public int mColorIndex = 0;
    private class BackgroundTask extends TimerTask {
        @Override
        public void run() {
            if(mColorIndex < mBackgroundColorList.size()){
                setBackgroundColor(mBackgroundColorList.get(mColorIndex));
                mColorIndex ++;
            }else {
                mColorIndex = 0;
                cancel();
            }
        }
    }

    public void brilliantRun(){
        if(!mBrilliantRun){
            Log.d("BrilliantRun", "brilliantRun: ");
            mBrilliantRun = true;
            mTimer = new Timer();
            mTimer.schedule(new BackgroundTask(), 0, 500);
        }
    }
    public void brilliantStop(){
        if(mBrilliantRun){
            Log.d("BrilliantRun", "brilliantStop: ");
            mBrilliantRun = false;
            if (mTimer != null) {
                mTimer.cancel();
            }
            setBackgroundColor(Color.parseColor("#66020202"));
        }
    }

    public void reset() {
        if (mTimer != null) {
            mTimer.cancel();
        }
        setBackgroundColor(Color.parseColor("#000000"));
        mBrilliantRun = false;
    }

    public void release() {
        if (mTimer != null) {
            mTimer.cancel();
        }
    }

    //对应颜色的HSB值为:白色(H:0，S:0，B:100)，黄色 (H:43、S:96，B:100)，蓝色(H:249、S:97，B:100)，
    //               绿色(H:123，S:72，B:100)，黑色(H:0，S:0，B:0)
    public ArrayList<Integer> getBackgroundColor() {
        ArrayList list = new ArrayList<Integer>();
        list.add(Color.parseColor("#FFFFFF"));
        list.add(Color.parseColor("#FFBA0A"));
        list.add(Color.parseColor("#2D08FF"));
        list.add(Color.parseColor("#47FF51"));
        list.add(Color.parseColor("#000000"));
        return list;
    }
}