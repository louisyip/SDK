package com.sensetime.interactive.widget;

import android.content.Context;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;

public class FaceOverlayView extends AbstractOverlayView {
    private @interface Orientation {
        int HORIZONTAL = 0;
        int VERTICAL = 1;
    }

    private @Orientation
    int mOrientation = Orientation.VERTICAL;

    private RectF mRectF = new RectF();

    public FaceOverlayView(Context context) {
        super(context);
    }

    public FaceOverlayView(Context context,
                           @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public FaceOverlayView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    /**
     * Set orientation.
     *
     * @param orientation orientation
     */
    public void setOrientation(@Orientation final int orientation) {
        this.mOrientation = orientation;
        this.invalidate();
    }

    @Override
    protected void buildPath(@NonNull Path path, int viewWidth, int viewHeight) {
        this.mRectF.set(viewWidth * 0.1f, viewHeight * 0.1f, viewWidth * 0.9f, viewHeight * 0.9f);

        path.addCircle(this.mRectF.centerX(), this.mRectF.centerY(), this.mRectF.width() / 2,
                Path.Direction.CCW);
    }

    @Override
    public Rect getMaskBounds() {
        float centerX = this.mRectF.centerX();
        float centerY = this.mRectF.centerY();
        float radius = this.mRectF.width() / 2;
        return new Rect(
                (int)(centerX - radius),
                (int)(centerY - radius),
                (int)(centerX + radius),
                (int)(centerY + radius));
    }
}
