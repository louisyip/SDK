package com.sensetime.interactive.widget;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;

//import androidx.appcompat.app.AppCompatDialog;
//import Button;

import com.sensetime.interactive.R;

/**
 * @Author: zhuyulinag
 * @CreateDate: 2020/5/6 2:59 PM
 * @Description: 提示权限设置
 */
public class PermissionDialog extends Dialog {

    protected boolean mIsCloseOutsideTouch = false;
    protected OnClickListener mListener =null;

    public PermissionDialog(Builder builder) {
        super(builder.mContext);
        init(builder);
    }

    private void init(Builder builder) {
        mIsCloseOutsideTouch = builder.mIsCloseOutsideTouch;
        mListener = builder.mListener;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        // 此处可以设置dialog显示的位置为居中
        window.setGravity(Gravity.CENTER);
        initView();
        initListener();
    }

    private void initListener() {}

    private void initView() {
        setCanceledOnTouchOutside(mIsCloseOutsideTouch);
        ViewGroup root = (ViewGroup)LayoutInflater.from(getContext()).inflate(R.layout.dialog_permission_hinit, null);
        ((Button)root.findViewById(R.id.btn_cancel)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onCancelClick(PermissionDialog.this);
            }
        });
        ((Button)root.findViewById(R.id.btn_ok)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onOkClick(PermissionDialog.this);
            }
        });
        setContentView(root);
    }

    public static class Builder {
        Context mContext = null;
        boolean mIsCloseOutsideTouch = false;
        OnClickListener mListener = null;

        public Builder setContext(Context context) {
            mContext = context;
            return this;
        }

        public Builder setIsCloseOutsideTouch(boolean isCloseOutsideTouch) {
            mIsCloseOutsideTouch = isCloseOutsideTouch;
            return this;
        }

        public Builder setOnClickListener(OnClickListener listener) {
            mListener = listener;
            return this;
        }

        public PermissionDialog build() {
            return new PermissionDialog(this);
        }
    }

    public interface OnClickListener {
        void onCancelClick(PermissionDialog dialog);

        void onOkClick(PermissionDialog dialog);
    }

}