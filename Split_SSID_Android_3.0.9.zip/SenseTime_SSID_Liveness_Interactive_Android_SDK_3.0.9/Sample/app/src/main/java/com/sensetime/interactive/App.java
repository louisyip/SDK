package com.sensetime.interactive;

import android.app.Application;

/**
 * @date: Create in 11:41 AM 2021/2/8
 * @author: chenliang
 * @description please add a description here
 */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
