package com.sensetime.interactive.ui;

import java.util.ArrayList;
import java.util.Locale;


import com.sensetime.interactive.R;
import com.sensetime.interactive.widget.AuthorizationDialog;
import com.sensetime.interactive.widget.PermissionDialog;
import com.sensetime.ssidmobile.sdk.liveness.interactive.BuildConfig;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @Author: zhuyulinag
 * @CreateDate: 2020/4/30 5:42 PM
 * @Description: 首页
 */
public class MainActivity extends FragmentActivity {

    public static int REQUEST_CODE_RESULT = 1;
    public static int REQUEST_CODE_PERMISSION = 3;
    public static boolean mIsAuthorization = false;

    protected Button mBtnInteractive;
    protected TextView mTxtVersion;
    protected TextView mTxtMessage;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBtnInteractive = findViewById(R.id.btn_interactive);
        mTxtVersion = findViewById(R.id.txt_version);
        findViewById(R.id.btn_interactive).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mIsAuthorization){
                    checkPermission();
                }else {
                    showAuthorizationDialog();
                }

            }
        });


        mTxtVersion.setText(this.getString(R.string.app_version, BuildConfig.VERSION_NAME));
        mTxtMessage = findViewById(R.id.message);
    }

    private void showAuthorizationDialog(){
        new AuthorizationDialog.Builder()
                .setContext(this)
                .setOnClickListener(new AuthorizationDialog.OnClickListener() {
                    @Override
                    public void onOkClick(AuthorizationDialog dialog) {
                        mIsAuthorization = true;
                        dialog.cancel();
                        checkPermission();
                    }

                    @Override
                    public void onCancelClick(AuthorizationDialog dialog) {
                        Toast.makeText(MainActivity.this,
                                R.string.authorization_cancel, Toast.LENGTH_SHORT).show();
                        dialog.cancel();
                    }
                })
                .build().show();
    }


    @Override
    protected void onResume() {
        super.onResume();
    }

    /**
     * 检查权限
     */
    private void checkPermission() {
        ArrayList<String> permissionArray = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(
                    getApplication(),
                    Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED) {
                permissionArray.add(Manifest.permission.CAMERA);
            }
            if (permissionArray != null && permissionArray.size() != 0) {
                String[] strings = new String[permissionArray.size()];
                permissionArray.toArray(strings);
                requestPermission(strings);
                return;
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                permissionArray.add(Manifest.permission.CAMERA);
            }
            if (permissionArray != null && permissionArray.size() != 0) {
                String[] permissions = new String[permissionArray.size()];
                permissionArray.toArray(permissions);
                requestPermission(permissions);
                return;
            }
        }
        InteractiveActivity.start(this);
    }

    /**
     * 请求权限
     */
    private void requestPermission(final String[] permissions) {
        new PermissionDialog.Builder()
                .setContext(this)
                .setOnClickListener(new PermissionDialog.OnClickListener() {
                    @Override
                    public void onCancelClick(PermissionDialog dialog) {
                        dialog.cancel();
                    }

                    @Override
                    public void onOkClick(PermissionDialog dialog) {
                        dialog.cancel();
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            ActivityCompat.requestPermissions(
                                    MainActivity.this, permissions,
                                    REQUEST_CODE_PERMISSION
                            );
                        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            requestPermissions(permissions,
                                    REQUEST_CODE_PERMISSION
                            );
                        }
                    }
                })
                .build().show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (requestCode == REQUEST_CODE_PERMISSION) {
            dealPermissionResult(requestCode, grantResults);
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void dealPermissionResult(int requestCode, int[] grantResults) {
        for (int i = 0; i < grantResults.length; i++) {
            if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                //permission denied
                Toast.makeText(this, R.string.error_permission, Toast.LENGTH_LONG).show();
                return;
            }
        }
        //permission allowed
        InteractiveActivity.start(this);
    }

    /**
     * 返回提示
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_RESULT) {
            return;
        }
        if (resultCode == Activity.RESULT_CANCELED) {
            Toast.makeText(this, R.string.canceled, Toast.LENGTH_LONG).show();
        } else if (resultCode == Activity.RESULT_OK) {
//            Intent intent = new Intent(data);
//            intent.setClass(MainActivity.this, ResultActivity.class);
//            startActivity(intent);
        } else {
        }
    }

}