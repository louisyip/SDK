package com.sensetime.interactive.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.sensetime.interactive.R;
import com.sensetime.interactive.utils.FileUtil;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.ResultCode;
import com.sensetime.ssidmobile.sdk.liveness.interactive.model.STImage;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.speech.tts.TextToSpeech;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * @date: Create in 2:29 PM 2020/5/21
 * @author: chenliang
 * @description please add a description here
 */
public class InteractiveResultActivity extends Activity {

    public final static String EXTRA_DETECTION_RESULT = "EXTRA_DETECTION_RESULT";
    public static List<byte[]> mSTImages = new ArrayList();
    public static List<Rect> mFaceRects = new ArrayList();
    public static void start(Context context, Result detectionResult) {
        Intent starter = new Intent(context, InteractiveResultActivity.class);
        starter.putExtra(EXTRA_DETECTION_RESULT, detectionResult);
        context.startActivity(starter);
    }

    protected TextView mTxtResult;
    protected RecyclerView mRecyclerView;
    protected ImageView mImageResult;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interactive_result);

        mTxtResult = findViewById(R.id.txt_result);
        mRecyclerView = findViewById(R.id.recycler);
        mImageResult = findViewById(R.id.result_bitmap);
        findViewById(R.id.goHome).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.quit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Result result = getIntent().getParcelableExtra(EXTRA_DETECTION_RESULT);
        int resultCode = result.resultCode;
        if (resultCode == ResultCode.OK) {
            mTxtResult.setText(R.string.txt_detect_success);
        } else if (resultCode == ResultCode.HACK) {
            mTxtResult.setText(R.string.txt_detect_fail);
            mTxtResult.setTextColor(Color.RED);
            mTxtResult.setCompoundDrawables(null, null, null, null);
        } else if (resultCode == ResultCode.TIME_OUT) {
            mTxtResult.setText(R.string.txt_error_timeout);
            mTxtResult.setTextColor(Color.RED);
            mTxtResult.setCompoundDrawables(null, null, null, null);
        }else if (resultCode == ResultCode.FACE_LOST) {
            mTxtResult.setText(R.string.txt_error_cancel_face_lost);
            mTxtResult.setTextColor(Color.RED);
            mTxtResult.setCompoundDrawables(null, null, null, null);
        } else if (resultCode == ResultCode.FACE_CHANGE) {
            mTxtResult.setText(R.string.txt_error_cancel_face_change);
            mTxtResult.setTextColor(Color.RED);
            mTxtResult.setCompoundDrawables(null, null, null, null);
        } else if (resultCode == ResultCode.READY_TIME_OUT) {
            mTxtResult.setText(R.string.txt_readr_error_timeout);
            mTxtResult.setTextColor(Color.RED);
            mTxtResult.setCompoundDrawables(null, null, null, null);
        } else if (resultCode == ResultCode.SYSTEM_ERROR) {
            mTxtResult.setText(R.string.common_error_system_risk);
            mTxtResult.setTextColor(Color.RED);
            mTxtResult.setCompoundDrawables(null, null, null, null);
        }  else if (resultCode == ResultCode.COLORFUL_FAILURE) {
            mTxtResult.setText(R.string.txt_detect_fail);
            mTxtResult.setTextColor(Color.RED);
            mTxtResult.setCompoundDrawables(null, null, null, null);
        } else {
            mTxtResult.setText(R.string.txt_error_canceled);
            mTxtResult.setTextColor(Color.RED);
            mTxtResult.setCompoundDrawables(null, null, null, null);
        }

        List<Pair<byte[], Rect>> faceResults = new ArrayList<>();
        for (int i = 0; i < mSTImages.size(); i++) {
            faceResults.add(new Pair<>(mSTImages.get(i),mFaceRects.get(i)));
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.HORIZONTAL));
        ResultAdapter resultAdapter = new ResultAdapter(faceResults);
        resultAdapter.addItemClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if (view instanceof ImageView){
                    mImageResult.setImageDrawable(((ImageView)view).getDrawable());
                }
            }
        });
        mRecyclerView.setAdapter(resultAdapter);
        //默认选中第一张
        mRecyclerView.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        try {
                            ResultViewHolder resultViewHolder =
                                    (ResultViewHolder) (mRecyclerView.getChildViewHolder(
                                            mRecyclerView.getChildAt(0)));
                            resultViewHolder.mImageView.performClick();
                        }catch (Exception e){
                            // 识别失败
                            e.printStackTrace();
                        }
                    }
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mSTImages.clear();
        mFaceRects.clear();
    }

    public static class ResultAdapter extends RecyclerView.Adapter<ResultViewHolder> {

        List<Pair<byte[], Rect>> filePathAndRectArray = new ArrayList<>();

        View.OnClickListener mItemClickListener;

        ResultAdapter(List<Pair<byte[], Rect>> filePaths) {
            this.filePathAndRectArray.addAll(filePaths);
        }

        @NonNull
        @Override
        public ResultViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ResultViewHolder(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_result_bitmap, null));
        }

        @Override
        public void onBindViewHolder(@NonNull ResultViewHolder holder, int position) {

            Pair<byte[], Rect> pair = filePathAndRectArray.get(position);
            byte[] bytes = pair.first;
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
//            Bitmap bitmap = BitmapFactory.decodeFile(pair.first);

            if (bitmap != null) {
                bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
                Canvas canvas = new Canvas(bitmap);
                Paint paint = new Paint();
                paint.setColor(Color.RED);
                paint.setStrokeWidth(3);
                paint.setStyle(Paint.Style.STROKE);
                canvas.drawRect(pair.second, paint);
                holder.mImageView.setImageBitmap(bitmap);
            }else {
                holder.mImageView.setImageBitmap(null);
            }
            holder.mImageView.setOnClickListener(mItemClickListener);
        }

        @Override
        public int getItemCount() {
            return filePathAndRectArray.size();
        }

        public void addItemClickListener(View.OnClickListener onClickListener) {
            mItemClickListener = onClickListener;
        }
    }

    private static class ResultViewHolder extends RecyclerView.ViewHolder {
        ImageView mImageView;

        public ResultViewHolder(@NonNull View view) {
            super(view);
            mImageView = view.findViewById(R.id.bitmap);
        }
    }

    public static class Result implements Parcelable {
        public int resultCode;
        List<String> bitmapFilePaths = new ArrayList<>();
        List<Rect> faceRects = new ArrayList<>();

        public void addBitmapFilePath(String filePath, Rect rect) {
            this.bitmapFilePaths.add(filePath);
            this.faceRects.add(rect);
        }

        public void addSTImage(Rect rect) {
            this.faceRects.add(rect);
        }

        public Result() {
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(this.resultCode);
            dest.writeStringList(this.bitmapFilePaths);
            dest.writeTypedList(this.faceRects);
        }

        protected Result(Parcel in) {
            this.resultCode = in.readInt();
            this.bitmapFilePaths = in.createStringArrayList();
            this.faceRects = in.createTypedArrayList(Rect.CREATOR);
        }

        public static final Creator<Result> CREATOR = new Creator<Result>() {
            @Override
            public Result createFromParcel(Parcel source) {
                return new Result(source);
            }

            @Override
            public Result[] newArray(int size) {
                return new Result[size];
            }
        };
    }
}
