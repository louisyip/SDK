//
//  STDetector.h
//  STDetector
//
//  Created by Sensetime Inc. on 2021/1/18.
//

#import <Foundation/Foundation.h>
#import <CoreMedia/CoreMedia.h>

NS_ASSUME_NONNULL_BEGIN
__attribute__((visibility("default")))
@interface STCommonDetector : NSObject

@end

NS_ASSUME_NONNULL_END
