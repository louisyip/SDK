package com.zhongan.liveness.log.core;


import org.json.JSONObject;

public interface ResponseCallback {

    /**
     * 请求成功而且没有错误的时候调用
     *
     * @param t
     */
    void onSuccess(JSONObject t);

    /**
     * 请求成功但是有错误的时候调用，例如Gson解析错误等
     *
     * @param errorCode
     * @param e
     */
    void onError(int errorCode, String errorMsg, Exception e);
}
