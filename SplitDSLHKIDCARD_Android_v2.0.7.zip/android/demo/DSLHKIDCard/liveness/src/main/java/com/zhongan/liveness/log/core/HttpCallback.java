package com.zhongan.liveness.log.core;

import com.alibaba.fastjson.JSONObject;

import okhttp3.Response;

public abstract class HttpCallback {


    /**
     * 请求之前调用
     */
    public abstract void onRequestBefore();

    /**
     * 请求失败调用（网络问题）
     *
     * @param
     */
    public abstract void onFailure(String failureMsg, int code);

    /**
     * 请求成功而且没有错误的时候调用
     *
     * @param response
     * @param t
     */
    public abstract void onSuccess(Response response, JSONObject t);

    /**
     * 请求成功但是有错误的时候调用，例如Gson解析错误等
     *
     * @param errorCode
     * @param e
     */
    public abstract void onError(int errorCode, Exception e);
}
