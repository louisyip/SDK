package com.zhongan.liveness.log.model;

import android.os.Build;

import java.io.Serializable;
import java.util.List;

public class LogInfoModel implements Serializable {

    private String deviceId;//设备标识
    private String osType="Android";//	操作系统类型
    private String appId;//ios取bundle id, 安卓取package id
    private String osVersion=Build.VERSION.RELEASE;//	操作系统版本
    private String deviceModel=Build.MANUFACTURER + "_" + Build.MODEL+"_"+Build.VERSION.RELEASE;//手机或终端的机型
    private String appVersion;//app的应用版本号
    private String timeStamp;//日志采集时间戳，单位：ms
    private int dataSource;//数据来源[0:活体检测， 1：身份证识别，99：其他]
    private String longType;//日志类型[0:normal, 1:error; 2:result, 99:其他]
    private String content;//日志内容：主要记录是错误，异常等
    private List<CustomModel> custom;//一个json结构的字符串，包括活体检测 或OCR识别的内容

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getOsType() {
        return osType;
    }

    public void setOsType(String osType) {
        this.osType = osType;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public String getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public int getDataSource() {
        return dataSource;
    }

    public void setDataSource(int dataSource) {
        this.dataSource = dataSource;
    }

    public String getLongType() {
        return longType;
    }

    public void setLongType(String longType) {
        this.longType = longType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<CustomModel> getCustom() {
        return custom;
    }

    public void setCustom(List<CustomModel> custom) {
        this.custom = custom;
    }
}
