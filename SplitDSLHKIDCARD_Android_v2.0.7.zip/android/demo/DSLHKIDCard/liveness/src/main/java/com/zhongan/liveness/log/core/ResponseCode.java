package com.zhongan.liveness.log.core;

public class ResponseCode {

    public static final int networkError=-1;//无网络
    public static final int msgError=1000;//和服务器交互错误
    public static final int dataError=1001;//数据错误
    public static final int msg_50=-50;//请求错误



}
