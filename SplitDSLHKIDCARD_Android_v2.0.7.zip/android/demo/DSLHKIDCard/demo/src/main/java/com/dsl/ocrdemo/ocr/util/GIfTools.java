package com.dsl.ocrdemo.ocr.util;

import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.dsl.ocr.util.DSLOcrApplications;

public class GIfTools {

    public static void gifPlay(int resource, ImageView ivGif){
        RequestOptions options = new RequestOptions()
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE);
        Glide.with(DSLOcrApplications.context()).load(resource).apply(options).into(ivGif);

    }

}
