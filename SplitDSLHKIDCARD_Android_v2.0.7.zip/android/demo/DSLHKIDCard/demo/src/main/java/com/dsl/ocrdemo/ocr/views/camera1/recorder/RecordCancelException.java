package com.dsl.ocrdemo.ocr.views.camera1.recorder;

public class RecordCancelException extends Exception {
    public RecordCancelException(String message) {
        super(message);
    }
}
