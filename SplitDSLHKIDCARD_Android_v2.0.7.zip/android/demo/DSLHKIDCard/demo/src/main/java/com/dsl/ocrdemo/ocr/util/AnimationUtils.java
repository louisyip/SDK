package com.dsl.ocrdemo.ocr.util;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;

import com.dsl.ocrdemo.ocr.views.Rotate3dAnimation;

public class AnimationUtils {

    private Rotate3dAnimation rotation;
    private StartNextRotate startNext;
    private EndNextRotate endNext;
    private View view;

    private  boolean  animationStop=false;

    private  boolean  animationResetStop=false;

    float start;
    float end;
    boolean isVertical;
    int type;

    private static AnimationUtils animmationUtils;

    public static AnimationUtils getInstance(){
        if(animmationUtils==null){
            synchronized (AnimationUtils.class){
                if(animmationUtils==null){
                    animmationUtils=new AnimationUtils();
                }
            }
        }
        return animmationUtils;
    }


    private class StartNextRotate implements Animation.AnimationListener {
        public void onAnimationEnd(Animation animation) {
            // TODO Auto-generated method stub
            if(!animationStop) {
                animationStop=false;
//                endRotation(view, end, start, isVertical, type);
            }
        }
        public void onAnimationRepeat(Animation animation) {
            // TODO Auto-generated method stub
        }
        public void onAnimationStart(Animation animation) {
            // TODO Auto-generated method stub
        }
    }

    private class EndNextRotate implements Animation.AnimationListener {
        public void onAnimationEnd(Animation animation) {
            // TODO Auto-generated method stub
            if(!animationStop) {
                animationStop=false;
                if(!animationResetStop) {
                    animationResetStop=false;
//                    startRotation(view, start, end, isVertical, type);
                }
            }
        }
        public void onAnimationRepeat(Animation animation) {
            // TODO Auto-generated method stub
        }
        public void onAnimationStart(Animation animation) {
            // TODO Auto-generated method stub
        }
    }

    public void animationStop(){
        animationResetStop=true;
    }

    public void animationClosed(){
        animationStop=true;
        if(view!=null) {
            view.clearAnimation();
        }
    }

    public void animationPrepare(){
        animationStop=false;
        animationResetStop=false;
    }



    public void endRotation(View rectangleView, float start, float end, boolean isVertical, int type) {
        view=rectangleView;
        rotation=null;
        this.start=start;
        this.end=end;
        this.isVertical=isVertical;
        this.type=type;

        // 计算中心点
        float centerX = rectangleView.getWidth();
        float centerY = rectangleView.getHeight()/2;
        switch (type){
            case  1:
                centerX=0;
                centerY = rectangleView.getHeight()/2;
                break;
            case 2:
                centerX=rectangleView.getWidth();
                centerY = rectangleView.getHeight()/2;
                break;
            case 3:
                centerX=rectangleView.getWidth()/2;
                centerY = rectangleView.getHeight();
                break;
            case 4:
                centerX=rectangleView.getWidth()/2;
                centerY = 0;
                break;

        }
        // Create a new 3D rotation with the supplied parameter
        // The animation listener is used to trigger the next animation
        //final Rotate3dAnimation rotation =new Rotate3dAnimation(start, end, centerX, centerY, 310.0f, true);
        //Z轴的缩放为0
        rotation =new Rotate3dAnimation(start, end, centerX, centerY, 0f, isVertical);
        rotation.setDuration(2000);
        rotation.setFillAfter(true);

        //匀速旋转
        rotation.setInterpolator(new LinearInterpolator());
        //设置监听
        endNext = new EndNextRotate();
        rotation.setAnimationListener(endNext);
        rectangleView.startAnimation(rotation);
    }


    public void startRotation(View rectangleView,float end,float start, boolean isVertical,int type) {
        animationPrepare();
        view=rectangleView;
        rotation=null;
        this.start=start;
        this.end=end;
        this.isVertical=isVertical;
        this.type=type;
        // 计算中心点
        float centerX = rectangleView.getWidth();
        float centerY = rectangleView.getHeight()/2;
        switch (type){
            case  1:
                centerX=0;
                centerY = rectangleView.getHeight()/2;
                break;
            case 2:
                centerX=rectangleView.getWidth();
                centerY = rectangleView.getHeight()/2;
                break;
            case 3:
                centerX=rectangleView.getWidth()/2;
                centerY = rectangleView.getHeight();
                break;
            case 4:
                centerX=rectangleView.getWidth()/2;
                centerY = 0;
                break;

        }

        // Create a new 3D rotation with the supplied parameter
        // The animation listener is used to trigger the next animation
        //final Rotate3dAnimation rotation =new Rotate3dAnimation(start, end, centerX, centerY, 310.0f, true);
        //Z轴的缩放为0
        rotation =new Rotate3dAnimation(start, end, centerX, centerY, 0f, isVertical);
        rotation.setDuration(3500);
        rotation.setFillAfter(true);

        //匀速旋转
        rotation.setInterpolator(new LinearInterpolator());
        //设置监听
        startNext = new StartNextRotate();
        rotation.setAnimationListener(startNext);
        rectangleView.startAnimation(rotation);
    }

    public float getDegrees(){
        float degree=0f;
        if(rotation!=null){
            degree=rotation.getDegrees();
        }
        return degree;
    }

}
