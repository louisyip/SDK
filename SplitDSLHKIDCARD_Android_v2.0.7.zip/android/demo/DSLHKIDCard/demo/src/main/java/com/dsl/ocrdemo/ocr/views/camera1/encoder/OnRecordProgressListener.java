package com.dsl.ocrdemo.ocr.views.camera1.encoder;

public interface OnRecordProgressListener {
    void onRecording(long dutationMs);
}
