package com.dsl.ocrdemo.ocr.receiver;

import android.annotation.SuppressLint;
import android.util.Log;

import com.dsl.ocr.manager.OcrNative;
import com.dsl.ocr.util.DSLHKCardType;
import com.dsl.ocr.util.DSLLog;
import com.dsl.ocrdemo.ocr.manager.OcrSDKManager;
import com.dsl.ocrdemo.ocr.util.Contants;
import com.dsl.ocrdemo.ocr.views.camera1.bean.VideoInfo;
import com.dsl.ocrdemo.ocr.views.camera1.interfaces.OnRecordListener;
import com.dsl.ocrdemo.ocr.views.camera1.recorder.SAbsVideoRecorder;

import java.io.File;
import java.util.Date;

public class DSLCamera1OcrReceiverMessage implements OnRecordListener {

    private VideoCallBackInterface videoCallBackInterface;

    private SAbsVideoRecorder mISVideoRecorder;

    private boolean isAlert = true;

    private boolean ecordFinished = false;


    @SuppressLint("StaticFieldLeak")
    private static final DSLCamera1OcrReceiverMessage ourInstance = new DSLCamera1OcrReceiverMessage();


    public static DSLCamera1OcrReceiverMessage getInstance() {
        return ourInstance;
    }


    private DSLCamera1OcrReceiverMessage() {

    }

    /**
     * 正常停止录制视频调用stopVideo停止录制视频
     */
    public void stopVideo(){
        if (mISVideoRecorder != null) {
            DSLLog.i("视频录制camera1","结束录制");
            mISVideoRecorder.stopRecord();
        }


    }

    /**
     * 当反光或速度过快，弹框的时候调用isAlertStopVideo停止录制视频
     */
    public void isAlertStopVideo(){
        isAlert=true;
        if (mISVideoRecorder != null) {
            DSLLog.i("视频录制camera1  isAlertStopVedio","结束录制");
            mISVideoRecorder.setIsAlertStopVideo(isAlert);
            mISVideoRecorder.stopRecord();
        }
    }


    /**
     * 开始录制视频
     */
    public void startRecord(){
        isAlert=false;
        ecordFinished=false;
        if (mISVideoRecorder != null) {
            DSLLog.i("视频录制camera1","开始录制");
            mISVideoRecorder.setIsAlertStopVideo(isAlert);
            mISVideoRecorder.startRecord();
        }
    }



    /**
     * 添加接受视频录制结束消息事件监听
     *
     * @param videoCallBackInterface
     */
    public void addVideoCallBackInterface(VideoCallBackInterface videoCallBackInterface, SAbsVideoRecorder sVideoRecorder) {
        this.videoCallBackInterface=videoCallBackInterface;
        this.mISVideoRecorder=sVideoRecorder;
        mISVideoRecorder.addRecordListener(this);
        DSLLog.i("录制视频","添加监听");
        OcrNative.getInstance().addOcrReceiveMessageListener(new OcrNative.OcrReceiveMessageListener() {
            @Override
            public void receiveMessage(String message) {
                if (DSLHKCardType.DSLHKIDCardRecStatus.DSLHKIDCardOperation_ORTH.toString().equals(message)) {
                    if (mISVideoRecorder!=null) {
                        Contants.dRecStartTimeStamp=new Date().getTime();
                        startRecord();
                    }
                } else if (DSLHKCardType.DSLHKIDCardRecStatus.DSLHKIDCardOperation_STOP3.toString().equals(message)) {
                    try {
                        if (mISVideoRecorder != null) {
                            Contants.dRecEndTimeStamp=new Date().getTime();
                            ecordFinished=true;
                            stopVideo();
                        }
                    }catch (Exception e){}
                }
            }
        });
    }

    /**
     * 移除接受视频录制结束消息事件监听
     *
     */
    public void removeVideoCallBackInterface() {
        this.videoCallBackInterface=null;
    }



    @Override
    public void onRecordSuccess(VideoInfo videoInfo) {
        DSLLog.i("视频录制onRecordSuccess",videoInfo.getVideoPath());
        Contants.video_time_length=videoInfo.getDuration();
        //当视频录制状态成功检测本地是否有视频文件
        if (!new File(OcrSDKManager.mp4).exists()) {
            if(videoCallBackInterface!=null) {
                videoCallBackInterface.videoError();
            }
            return;
        }
        if(!isAlert && videoCallBackInterface!=null && ecordFinished) {
            videoCallBackInterface.videoFinished();
        }
    }

    @Override
    public void onRecordStart() {
        DSLLog.i("视频录制", "onRecordStart");
    }

    @Override
    public void onRecordFail(Throwable t) {
        DSLLog.i("视频录制", "onRecordFail");
        if(videoCallBackInterface!=null) {
            videoCallBackInterface.videoError();
        }
    }

    @Override
    public void onRecordStop() {
        DSLLog.i("视频录制", "onRecordStop");
    }

    @Override
    public void onRecordPause() {
        DSLLog.i("视频录制", "onRecordPause");

    }

    @Override
    public void onRecordResume() {
        DSLLog.i("视频录制", "onRecordResume");
    }
}
