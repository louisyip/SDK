package com.dsl.ocrdemo.ocr.receiver;

public interface VideoCallBackInterface {

    void videoFinished();

    void videoError();

}
