package com.dsl.ocrdemo.ocr.views;

import android.graphics.Camera;
import android.graphics.Matrix;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.Transformation;

import com.dsl.ocr.util.DSLLog;

public class Rotate3dAnimation extends Animation {
    private final float mFromDegrees;
    private final float mToDegrees;
    private final float mCenterX;
    private final float mCenterY;
    private final float mDepthZ;
    private final boolean isVertical;

    private float mDegrees;


    private Camera mCamera;
    /**
     * Creates a new 3D rotation on the Y axis. The rotation is defined by its
     * start angle and its end angle. Both angles are in degrees. The rotation
     * is performed around a center point on the 2D space, definied by a pair
     * of X and Y coordinates, called centerX and centerY. When the animation
     * starts, a translation on the Z axis (depth) is performed. The length
     * of the translation can be specified, as well as whether the translation
     * should be reversed in time.
     *
     * @param fromDegrees the start angle of the 3D rotation
     * @param toDegrees the end angle of the 3D rotation
     * @param centerX the X center of the 3D rotation
     * @param centerY the Y center of the 3D rotation
     * @param isVertical true Vertical, false horizontal
     */
    public Rotate3dAnimation(float fromDegrees, float toDegrees,
                             float centerX, float centerY, float depthZ, boolean isVertical) {
        mFromDegrees = fromDegrees;
        mToDegrees = toDegrees;
        mCenterX = centerX;
        mCenterY = centerY;
        mDepthZ = depthZ;
        this.isVertical = isVertical;
    }
    @Override
    public void initialize(int width, int height, int parentWidth, int parentHeight) {
        super.initialize(width, height, parentWidth, parentHeight);
        mCamera = new Camera();
    }
    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        final float fromDegrees = mFromDegrees;
        float degrees = mToDegrees + ((fromDegrees - mToDegrees) * interpolatedTime);
        mDegrees=degrees;
        final float centerX = mCenterX;
        final float centerY = mCenterY;
        final Camera camera = mCamera;
        final Matrix matrix = t.getMatrix();
        //保存一次camera初始状态，用于restore()
        camera.save();
        camera.translate(0.0f, 0.0f, mDepthZ * interpolatedTime);
//        camera.translate(0.0f, 0.0f, mDepthZ * (1.0f - interpolatedTime));
        if(isVertical){
            //围绕X轴旋转degrees度
            camera.rotateY(degrees);
        }else{
            //围绕Y轴旋转degrees度
            camera.rotateX(degrees);
        }

        //行camera中取出矩阵，赋值给matrix
        camera.getMatrix(matrix);
        //camera恢复到初始状态，继续用于下次的计算
        camera.restore();
        matrix.preTranslate(-centerX, -centerY);
        matrix.postTranslate(centerX, centerY);
    }

    private void setmDegrees(float degrees){
        mDegrees=degrees;
    }

    public float getDegrees(){
        return  mDegrees;
    }

}
