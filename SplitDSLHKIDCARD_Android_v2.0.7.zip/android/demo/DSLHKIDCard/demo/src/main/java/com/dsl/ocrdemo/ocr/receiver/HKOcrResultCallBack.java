package com.dsl.ocrdemo.ocr.receiver;

public interface HKOcrResultCallBack {

    public void result(int resultCode,String result);

}
