package com.dsl.ocrdemo.ocr.views.camera1.utils;

import com.dsl.ocr.util.DSLLog;

public class RL {
    private RL() {
    }


    public static void v(String message, Object... args) {
        DSLLog.v("RL",message);
    }

    public static void v(Throwable ex) {
        if(ex!=null) {
            DSLLog.v("RL", ex.getMessage());
        }
    }

    public static void vt(String tag, String message, Object... args) {
        DSLLog.v("RL", message);
    }

    public static void d(String message, Object... args) {
        DSLLog.d("RL", message);
    }

    public static void d(Throwable ex) {
        if(ex!=null) {
            DSLLog.v("RL", ex.getMessage());
        }
    }

    public static void dt(String tag, String message, Object... args) {
        DSLLog.v("RL", message);
    }

    public static void i(String message, Object... args) {
        DSLLog.i("RL", message);
    }

    public static void i(Throwable ex) {
        if(ex!=null) {
            DSLLog.v("RL", ex.getMessage());
        }
    }

    public static void it(String tag, String message, Object... args) {
        DSLLog.v("RL", message);

    }

    public static void w(String message, Object... args) {
        DSLLog.v("RL", message);
    }

    public static void w(Throwable ex) {
        if(ex!=null) {
            DSLLog.v("RL", ex.getMessage());
        }
    }

    public static void wt(String tag, String message, Object... args) {
        DSLLog.v("RL", message);
    }

    public static void e(String message, Object... args) {
        DSLLog.v("RL", message);
    }

    public static void e(Throwable ex) {
        if(ex!=null) {
            DSLLog.v("RL", ex.getMessage());
        }
    }

    public static void et(String tag, String message, Object... args) {
        DSLLog.v("RL", message);
    }

    public static void wtf(String message, Object... args) {
        DSLLog.v("RL", message);
    }

    public static void printStackTrace(String tag) {
        DSLLog.v("RL", tag);
    }
}
