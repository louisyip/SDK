package com.dsl.ocrdemo.ocr.views.camera1.recorder;

public interface OnRecordFailListener {
    void onVideoRecordFail(Throwable e, final boolean showToast);
}
