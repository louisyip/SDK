package com.dsl.ocrdemo.ocr.util;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

import com.dsl.ocrdemo.R;

import java.util.HashMap;

public class VoicePlayer {

    SoundPool sp; // 声明SoundPool的引用
    HashMap<Integer, Integer> hm; // 声明一个HashMap来存放声音文件
    int currStreamId;// 当前正播放的streamId

    private static VoicePlayer instance;

    public static VoicePlayer getInstance(){
        if(instance==null){
            synchronized (VoicePlayer.class){
                if(instance==null){
                    instance=new VoicePlayer();
                }
            }
        }
        return instance;
    }


    // 播放声音的方法
    public void playSound(Context context, final int sound, final int loop) { // 获取AudioManager引用
        AudioManager am = (AudioManager) context
                .getSystemService(Context.AUDIO_SERVICE);
        // 获取当前音量
        float streamVolumeCurrent = am
                .getStreamVolume(AudioManager.STREAM_MUSIC);
        // 获取系统最大音量
        float streamVolumeMax = am
                .getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        // 计算得到播放音量
        final float volume = streamVolumeCurrent / streamVolumeMax;
        if(sp!=null) {
            sp.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                @Override
                public void onLoadComplete(SoundPool soundPool, int sampleId, int status) {
                    // 调用SoundPool的play方法来播放声音文件
                    currStreamId = sp.play(hm.get(sound), volume, volume, 1, loop, 1.0f);
                }
            });

        }

    }

    // 初始化声音池的方法
    public void initSoundPool(Context context) {
        sp = new SoundPool(4, AudioManager.STREAM_MUSIC, 0); // 创建SoundPool对象
        hm = new HashMap<Integer, Integer>(); // 创建HashMap对象
        hm.put(1, sp.load(context, R.raw.op_success, 1)); // 加载声音文件musictest并且设置为1号声音放入hm中
    }

    public void stopSound(){
        if(sp!=null) {
            sp.stop(currStreamId); // 停止正在播放的某个声音
        }
    }

}
