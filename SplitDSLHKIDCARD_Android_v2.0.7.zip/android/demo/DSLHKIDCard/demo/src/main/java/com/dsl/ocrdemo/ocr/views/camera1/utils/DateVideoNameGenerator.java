package com.dsl.ocrdemo.ocr.views.camera1.utils;

import java.io.File;

import com.dsl.ocrdemo.ocr.manager.OcrSDKManager;
import com.dsl.ocrdemo.ocr.views.camera1.interfaces.IVideoPathGenerator;

public class DateVideoNameGenerator implements IVideoPathGenerator {
    @Override
    public String generate() {
        File dir = new File(OcrSDKManager.basePath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return OcrSDKManager.mp4;
    }
}
