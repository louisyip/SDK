package com.dsl.ocrdemo.ocr.manager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;

import com.dsl.ocrdemo.DSLLocalHandHKIDActivity;
import com.dsl.ocrdemo.ocr.DSLHandHKIDActivity;
import com.dsl.ocrdemo.ocr.receiver.HKOcrResultCallBack;
import com.dsl.ocr.manager.OcrNative;
import com.dsl.ocr.util.DSLLog;
import com.dsl.ocr.util.DSLOcrApplications;
import com.dsl.ocrdemo.DSLLocalHKIDActivity;
import com.dsl.ocrdemo.ocr.DSLHKIDActivity;
import com.dsl.ocrdemo.ocr.util.Contants;


/**
 * ocr 管理器
 *
 */
public class OcrSDKManager {

    public static String basePath=DSLOcrApplications.context().getExternalCacheDir()+"/ocrFile/";

    public static String mp4 = OcrSDKManager.basePath + "hk_ocr.mp4";

    public static String compress_mp4 = OcrSDKManager.basePath + "hk_ocr_compress.mp4";

    public static String za_hk_face=OcrSDKManager.basePath+"za_hk_face.png";

    public static String za_hk_idcard=OcrSDKManager.basePath+"za_hk_idcard.png";

    public static String za_hk_live_face=OcrSDKManager.basePath+"za_hk_live_face.png";

    public static String za_hk_takephoto=OcrSDKManager.basePath+"za_hk_takephoto.png";

    private long mLastClickTime = 0;
    public static final long TIME_INTERVAL = 1000L;

    /**
     * 是否为调试模式
     */
    private boolean mIsDebugModle;

    @SuppressLint("StaticFieldLeak")
    private static final OcrSDKManager ourInstance = new OcrSDKManager();


    private OcrNative mOcrNative;

    private HKOcrResultCallBack mHkOcrResultCallBack;

    public static synchronized OcrSDKManager getInstance() {
        return ourInstance;
    }

    private OcrSDKManager() {
        mOcrNative = OcrNative.getInstance();
    }

    /**
     * 是否开启调试模式
     *
     * @param isDebug
     */
    public void enableDebug(boolean isDebug) {
        mIsDebugModle = isDebug;
        DSLLog.setDebug(mIsDebugModle);
    }

    public void initBinBasePath(String binBasePath){
        mOcrNative.initBinBasePath(binBasePath);
    }

    /**
     * 桌面版本2018
     */
    public void startDeskTopIDCard2018(Activity context,boolean isDebug,boolean isLite) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            // do something
            mLastClickTime = nowTime;
            Contants.isOldOrNew = 2;
            enableDebug(isDebug);
            mOcrNative.initBin(context, Contants.isOldOrNew);
            Intent intent = new Intent(context, DSLHKIDActivity.class);
            intent.putExtra("from","NEW_HK_CARD");
            intent.putExtra("isLite",isLite);
            context.startActivity(intent);
        }
    }

    /**
     * 桌面版本2003
     */
    public void startDeskTopIDCard2003(Activity context,boolean isDebug,boolean isLite) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            // do something
            mLastClickTime = nowTime;
            Contants.isOldOrNew = 1;
            enableDebug(isDebug);
            mOcrNative.initBin(context, Contants.isOldOrNew);
            Intent intent = new Intent(context, DSLHKIDActivity.class);
            intent.putExtra("from","OLD_HK_CARD");
            intent.putExtra("isLite",isLite);
            context.startActivity(intent);
        }
    }



    /**
     * 手持版本2018
     */
    public void startHandIDCard2018(Activity context,boolean isDebug,boolean isLite) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            // do something
            mLastClickTime = nowTime;
            Contants.isOldOrNew = 2;
            enableDebug(isDebug);
            mOcrNative.initBin(context, Contants.isOldOrNew);
            Intent intent = new Intent(context, DSLHandHKIDActivity.class);
            intent.putExtra("from","NEW_HK_CARD");
            intent.putExtra("isLite",isLite);
            context.startActivity(intent);
        }
    }

    /**
     * 手持版本2003
     */
    public void startHandIDCard2003(Activity context,boolean isDebug,boolean isLite) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            // do something
            mLastClickTime = nowTime;
            Contants.isOldOrNew = 1;
            enableDebug(isDebug);
            mOcrNative.initBin(context, Contants.isOldOrNew);
            Intent intent = new Intent(context, DSLHandHKIDActivity.class);
            intent.putExtra("from","OLD_HK_CARD");
            intent.putExtra("isLite",isLite);
            context.startActivity(intent);
        }
    }




    /**
     * 桌面离线版本2018
     */
    public void startDeskTopOfflineIDCard2018(Activity context,boolean isDebug) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            // do something
            mLastClickTime = nowTime;
            Contants.isOldOrNew = 2;
            enableDebug(isDebug);
            mOcrNative.initBin(context, Contants.isOldOrNew);
            Intent intent = new Intent(context, DSLLocalHKIDActivity.class);
            intent.putExtra("from","NEW_HK_CARD");
            context.startActivity(intent);
        }
    }

    /**
     * 桌面离线版本2003
     */
    public void startDeskTopOfflineIDCard2003(Activity context,boolean isDebug) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            // do something
            mLastClickTime = nowTime;
            Contants.isOldOrNew = 1;
            enableDebug(isDebug);
            mOcrNative.initBin(context, Contants.isOldOrNew);
            Intent intent = new Intent(context, DSLLocalHKIDActivity.class);
            intent.putExtra("from","OLD_HK_CARD");
            context.startActivity(intent);
        }
    }

    /**
     * 手持离线版本2018
     */
    public void startHandOfflineIDCard2018(Activity context,boolean isDebug) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            // do something
            mLastClickTime = nowTime;
            Contants.isOldOrNew = 2;
            enableDebug(isDebug);
            mOcrNative.initBin(context, Contants.isOldOrNew);
            Intent intent = new Intent(context, DSLLocalHandHKIDActivity.class);
            intent.putExtra("from","NEW_HK_CARD");
            context.startActivity(intent);
        }
    }

    /**
     * 手持离线版本2003
     */
    public void startHandOfflineIDCard2003(Activity context,boolean isDebug) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            // do something
            mLastClickTime = nowTime;
            Contants.isOldOrNew = 1;
            enableDebug(isDebug);
            mOcrNative.initBin(context, Contants.isOldOrNew);
            Intent intent = new Intent(context, DSLLocalHandHKIDActivity.class);
            intent.putExtra("from","OLD_HK_CARD");
            context.startActivity(intent);
        }
    }

    public void addHKOcrResultCallBack(HKOcrResultCallBack hkOcrResultCallBack){
        mHkOcrResultCallBack=hkOcrResultCallBack;
    }

    public HKOcrResultCallBack getHKOcrResultCallBack(){
        return mHkOcrResultCallBack;
    }

    public void initVideoPath(String videoBasePath){
        basePath=videoBasePath;
        mp4 = OcrSDKManager.basePath + "hk_ocr.mp4";
        compress_mp4 = OcrSDKManager.basePath + "hk_ocr_compress.mp4";
        za_hk_face=OcrSDKManager.basePath+"za_hk_face.png";
        za_hk_idcard=OcrSDKManager.basePath+"za_hk_idcard.png";
        za_hk_live_face=OcrSDKManager.basePath+"za_hk_live_face.png";
        za_hk_takephoto=OcrSDKManager.basePath+"za_hk_takephoto.png";
    }


}
