package com.dsl.ocrdemo.ocr.receiver;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View;

import com.dsl.ocr.util.DSLLog;
import com.dsl.ocrdemo.R;
import com.dsl.ocrdemo.ocr.views.CameraBaseView;

public class DSLOcrReceiverMessage {

//    private static int INFO_SUPPORTED_HARDWARE_LEVEL;

    CameraBaseView mCameraView=null;


    @SuppressLint("StaticFieldLeak")
    private static final DSLOcrReceiverMessage ourInstance = new DSLOcrReceiverMessage();


    public static DSLOcrReceiverMessage getInstance() {
        return ourInstance;
    }

    public  CameraBaseView init(Activity mActivity){


        mCameraView = mActivity.findViewById(R.id.camera1);
        mCameraView.setVisibility(View.VISIBLE);

        mCameraView.init(mActivity);

        mCameraView.startCamera();

        return mCameraView;
    }

    /**
     * 正常停止录制视频调用stopVideo停止录制视频
     */
    public void stopVideo(){
        DSLCamera1OcrReceiverMessage.getInstance().stopVideo();
    }

    /**
     * 当反光或速度过快，弹框的时候调用isAlertStopVideo停止录制视频
     */
    public void isAlertStopVideo(){
        DSLCamera1OcrReceiverMessage.getInstance().isAlertStopVideo();
    }



    /**
     * 添加接受视频录制结束消息事件监听
     *
     * @param videoCallBackInterface
     */
    public void addVideoCallBackInterface(VideoCallBackInterface videoCallBackInterface) {
        DSLCamera1OcrReceiverMessage.getInstance().addVideoCallBackInterface(videoCallBackInterface,mCameraView.requestRecordListener());
    }

    /**
     * 移除接受视频录制结束消息事件监听
     *
     */
    public void removeVideoCallBackInterface() {
        DSLCamera1OcrReceiverMessage.getInstance().removeVideoCallBackInterface();
    }

    public void stopCamera(){
        if(mCameraView!=null) {
            mCameraView.stopCamera();
        }
    }

    public void closeCamera(){
        if(mCameraView!=null) {
            mCameraView.closeCamera();
        }
    }

}
