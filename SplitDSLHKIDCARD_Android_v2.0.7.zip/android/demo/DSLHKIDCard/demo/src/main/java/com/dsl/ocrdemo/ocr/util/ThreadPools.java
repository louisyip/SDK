package com.dsl.ocrdemo.ocr.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 线程池工具类
 */
public class ThreadPools {
	static ExecutorService mExecutorService = Executors.newFixedThreadPool(4);

	/**
	 * 把任务交给线程池运行
	 * @param task
	 */
	public synchronized static void execute(Runnable task) {
		mExecutorService.execute(task);
	}
}
