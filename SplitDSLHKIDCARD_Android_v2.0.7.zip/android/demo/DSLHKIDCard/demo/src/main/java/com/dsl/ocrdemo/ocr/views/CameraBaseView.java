package com.dsl.ocrdemo.ocr.views;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.TextureView;

import com.dsl.ocr.util.DSLLog;
import com.dsl.ocrdemo.ocr.views.camera1.recorder.SAbsVideoRecorder;

public abstract class CameraBaseView extends TextureView {

    public int cameraHeight;//对应竖屏的宽度，横屏的高度

    public int cameraWidth;//对应竖屏的高度，横屏的宽度

    public CameraBaseView(Context context) {
        super(context);
    }

    public CameraBaseView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CameraBaseView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        if(cameraWidth == 0 || cameraHeight == 0){
            setMeasuredDimension(width,height);
        }else{
            if (width > height * cameraHeight / cameraWidth) {
                setMeasuredDimension(width, width * cameraWidth / cameraHeight);
            } else {
                setMeasuredDimension(height * cameraHeight / cameraWidth, height);
            }
        }
    }


    public abstract void init(Activity activity);

    public abstract void startCamera();

    public abstract void stopCamera();

    public abstract void closeCamera();

    public abstract void takePhoto();

    public abstract void changeFlashLight(boolean openOrClose);

    public abstract SAbsVideoRecorder requestRecordListener();


}
